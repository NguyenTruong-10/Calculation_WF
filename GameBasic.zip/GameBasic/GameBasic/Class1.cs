﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameBasic
{
    public class Save
    {

        public static int real_money ;
        
    }
}
